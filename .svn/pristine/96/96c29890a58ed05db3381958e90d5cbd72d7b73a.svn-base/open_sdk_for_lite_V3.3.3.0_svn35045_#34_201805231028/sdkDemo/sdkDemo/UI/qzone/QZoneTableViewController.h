//
//  QZoneTableViewController.h
//  sdkDemo
//
//  Created by qqconnect on 13-7-8.
//  Copyright (c) 2013年 qqconnect. All rights reserved.
//

#import "SdkTableViewController.h"

@interface QZoneTableViewController : SdkTableViewController

@property (nonatomic, retain)NSString *albumId;

@end
