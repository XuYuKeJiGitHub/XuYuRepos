//
//  addShareViewController.h
//  sdkDemo
//
//  Created by qqconnect on 13-4-2.
//  Copyright (c) 2013年 qqconnect. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface addShareViewController : UIViewController

@end
