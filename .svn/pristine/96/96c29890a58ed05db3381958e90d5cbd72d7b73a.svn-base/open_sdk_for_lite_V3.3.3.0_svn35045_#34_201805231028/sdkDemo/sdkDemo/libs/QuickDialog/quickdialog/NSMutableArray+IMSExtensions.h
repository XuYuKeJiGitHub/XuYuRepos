//
//  NSMutableArray+IMSExtensions.h
//  QuickDialog
//
//  Created by Iain Stubbs on 16/02/12.
//  Copyright (c) 2012 Parallel ThirtyEight South. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableArray (IMSExtensions)

- (NSString*)concatStrings;

@end

