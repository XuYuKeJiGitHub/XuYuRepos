#import <Foundation/Foundation.h>

NSString *QTranslate(NSString *value);
#import "QuickDialogController.h"

@interface QuickDialogController (Helpers)

@end